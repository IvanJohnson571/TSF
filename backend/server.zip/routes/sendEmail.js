const express = require("express");
const nodemailer = require('nodemailer');
const router = express.Router();
//const userGMail = 'ivanjohnson58@gmail.com';
const userGMail = 'ivan_johnson2005@yahoo.com';
//const pass = 'cgju jqyq zlbe pluc'; //NOTE: google account - old
//const pass = 'rgyu miew meab jfni'; //NOTE: google account.
//const pass = 'zzmwvotllrzqlbnq'; //NOTE: yahoo account. //https://tsf-bg.com
const pass = 'kqujzpqvhxiwddpr'; //NOTE: yahoo account. //test

var endOfTextData = '';

function sendEmail(query) {

  endOfTextData = " от: " + query.name + ', тел: ' + query.phone + ', поща: ' + query.email;

  return new Promise((resolve, reject) => {

    var transporter = nodemailer.createTransport({

      //host: 'live.smtp.mailtrap.io',
      //port: 587,
      //secure: false,
      //auth: {
      //  user: 'api',
      //  pass: 'd7f6c1eec9a5646ae437c15e96de3cd8'
      //}

      host: 'smtp.mail.yahoo.com', //smtp.mail.yahoo.com, //imap.mail.yahoo.com:993/imap/ssl/novalidate-cert
      port: 465,//465, 25, 26
      service: 'yahoo',
      secure: true,
      auth: {
        user: userGMail,
        pass: pass
      },
      tls: { rejectUnauthorized: false },
      //debug: false,
      //logger: true

    });

    var mailOptions = {
      from: query.email,
      to: userGMail,
      subject: query.subject,
      text: query.message + endOfTextData,
      generateTextFromHTML: true,
      html: "" //То do!!!
    };

    transporter.sendMail(mailOptions, function (error, info) {

      if (error) {
        //return reject({ message: 'An error has occured!' });
        return reject({ message: error });

      }

      return resolve({ message: "Email sent successfully!" });

    });

  });

}

router.get("", (req, res, next) => {

  sendEmail(req.query)
    .then((response) => {
      res.status(200).json({
        success: true,
        data: response.message
      });
    })
    .catch((error) => {
      res.status(500).send(error/*error.message*/);
    });

});

module.exports = router;
