const galleryTwoList = [{
  "_id": {
    "$oid": "6406200c240013ef1d904ee3"
  },
  "path": "http://localhost:3000/images/Gallery/IMG-4261.jpg"
}, {
  "_id": {
    "$oid": "64074c2f67488cb1719fb431"
  },
  "path": "http://localhost:3000/images/Gallery/band.jpg"
}, {
  "_id": {
    "$oid": "640b329258d3f6eae8ae0a35"
  },
  "path": "http://localhost:3000/images/Gallery/10.jpg"
}, {
  "_id": {
    "$oid": "640b32dd58d3f6eae8ae0a36"
  },
  "path": "http://localhost:3000/images/Gallery/11.jpg"
}, {
  "_id": {
    "$oid": "640b32e758d3f6eae8ae0a37"
  },
  "path": "http://localhost:3000/images/Gallery/12.jpg"
  }];

module.exports = galleryTwoList;
