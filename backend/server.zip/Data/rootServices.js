const rootServices = [
  {
  "_id": {
    "$oid": "64072e6067488cb1719fb42b"
  },
  "url": "icon-3c.png",
  "name": "Аудио Записи"
}, {
  "_id": {
    "$oid": "64072e8767488cb1719fb42c"
  },
    "url": "icon-5c.png",
  "name": "Репетиции"
}, {
  "_id": {
    "$oid": "64072eb267488cb1719fb42d"
  },
    "url": "camera-2.png",
  "name": "Видео"
}, {
  "_id": {
    "$oid": "64072ecd67488cb1719fb42e"
  },
    "url": "icon-2c.png",
  "name": "Мастъринг"
}, {
  "_id": {
    "$oid": "64072eed67488cb1719fb42f"
  },
  "url": "icon-5c.png",
  "name": "Миксинг"
  },
  {
    "_id": {
      "$oid": null
    },
    "url": "concert-sportlight.png",
    "name": "Озвучаване и осветление на концерти и корпоративни мероприятия"
  }

];

module.exports = rootServices;
