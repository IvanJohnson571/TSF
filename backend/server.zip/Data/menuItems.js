const menuItems = [{
  "_id": {
    "$oid": "6407264467488cb1719fb424"
  },
  "Description": "Начало",
  "Item": ""
}, {
  "_id": {
    "$oid": "6407268f67488cb1719fb425"
  },
  "Description": "Оборудване",
  "Item": "equipment"
}, {
  "_id": {
    "$oid": "640726cb67488cb1719fb426"
  },
  "Description": "Зали",
  "Item": "halls"
}, {
  "_id": {
    "$oid": "640729a867488cb1719fb427"
  },
  "Description": "Цени",
  "Item": "prices"
}, {
  "_id": {
    "$oid": "640729d767488cb1719fb428"
  },
  "Description": "Контакти",
  "Item": "contacts"
}, {
  "_id": {
    "$oid": "640729fe67488cb1719fb429"
  },
  "Description": "За Нас",
  "Item": "about"
}, {
  "_id": {
    "$oid": "640a154254a64cabd5000836"
  },
  "Description": "Медия",
  "Item": "audio-video"
}];

module.exports = menuItems;
